
package recuperatorio_primer_parcial;


public class JugadorDuplicadoException extends Exception{
    
    public JugadorDuplicadoException(String mensaje) {
        super(mensaje);
        
    }
    
}
