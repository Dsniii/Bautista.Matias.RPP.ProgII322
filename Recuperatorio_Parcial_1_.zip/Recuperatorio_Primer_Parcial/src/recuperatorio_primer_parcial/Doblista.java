
package recuperatorio_primer_parcial;


public class Doblista extends Jugador implements PracticarEnPareja{
    
    private int coordicion; 
    public Doblista(String nombre, int ranking, Superficie superficiePreferida, int indiceCoordinacion) {
        super(nombre, ranking, superficiePreferida);

        if (indiceCoordinacion < 1 || indiceCoordinacion > 10) {
            throw new IllegalArgumentException("El índice de coordinación debe ser entre 1 y 10.");
        }

        this.coordicion = indiceCoordinacion;
    }

    public int getCoordinacion() {
        return coordicion;
    }

    
    public void sacar() {
        System.out.println(getNombre() + " realiza un saque coordinado.");
    }

    
    public void practicaEnPareja() {
        System.out.println(getNombre() + " practica en pareja (índice: " + coordicion + ").");
    }

    @Override
    public String toString() {
        return "Doblista " + super.toString() +" indice de coordinacion: " + coordicion;
    }
    
    
}
