/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package recuperatorio_primer_parcial;


public class Singlista extends Jugador implements Saque{
    
   private int velocidad;

    public Singlista(String nombre, int ranking, Superficie superficiePreferida, int velocidadSaque) {
        super(nombre, ranking, superficiePreferida);

        if (velocidadSaque <= 0) {
            throw new IllegalArgumentException("La velocidad de saque debe ser mayor que 0.");
        }

        this.velocidad = velocidadSaque;
    }

    public int getVelocidad() {
        return velocidad;
    }

    @Override
    public void sacar() {
        System.out.println(getNombre() + " saca a " + velocidad + " km/h.");
    }

    @Override
    public String toString() {
        return "Singlista " + super.toString() + " Velocidad de saque: " + velocidad;
    }
    
    
}
