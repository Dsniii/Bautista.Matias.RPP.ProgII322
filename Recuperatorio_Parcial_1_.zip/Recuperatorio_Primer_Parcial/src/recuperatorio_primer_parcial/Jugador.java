
package recuperatorio_primer_parcial;


public abstract class Jugador {
    
    private String nombre;
    private int ranking;
    private Superficie superficie;

    public Jugador(String nombre, int ranking, Superficie superficiePreferida) {

        if (nombre == null || nombre.isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }

        if (ranking <= 0) {
            throw new IllegalArgumentException("El ranking debe ser mayor que 0.");
        }

        if (superficiePreferida == null) {
            throw new IllegalArgumentException("La superficie no puede ser nula.");
        }

        this.nombre = nombre;
        this.ranking = ranking;
        this.superficie = superficiePreferida;
    }

    public String getNombre() {
        return nombre;
    }

    public int getRanking() {
        return ranking;
    }

    public Superficie getSuperficie() {
        return superficie;
    }

   
    @Override
    public boolean equals(Object objeto) {

        if (this == objeto){
            return true;
        }
        if (objeto == null || getClass() != objeto.getClass()){
            return false;
        }

        Jugador otro = (Jugador) objeto;

        return ranking == otro.ranking && nombre.equalsIgnoreCase(otro.nombre);
    }

    @Override
    public int hashCode() {
        return nombre.toLowerCase().hashCode() + (ranking * 31);
    }

    @Override
    public String toString() {
        return "Nombre: " + nombre + " Ranking: " + ranking +" Superficie: " + superficie;
    }
    
    
    
}
