
package recuperatorio_primer_parcial;


public interface PracticarEnPareja {
    void practicaEnPareja();
}
