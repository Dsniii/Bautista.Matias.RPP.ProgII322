
package recuperatorio_primer_parcial;
import java.util.ArrayList;


public class Vestuario {
    
    
    private ArrayList<Jugador> jugadores = new ArrayList<>();

    
    public void agregarJugador(Jugador jugador) throws JugadorDuplicadoException {
        
        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo");
        }

        if (jugadores.contains(jugador)) {
            throw new JugadorDuplicadoException(
                "El jugador '" + jugador.getNombre() + "' con ranking " + jugador.getRanking() + " ya existe"
            );
        }

        jugadores.add(jugador);
    }

   
    public void mostrarJugadores() {
        for (Jugador jugador : jugadores) {
            System.out.println(jugador);
        }
    }

 
    public void sacar(Jugador jugador) {

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo");
        }

        if (jugador instanceof Saque) {
            ((Saque) jugador).sacar();
        } else {
            System.out.println("Este jugador no puede sacar");
        }
    }

    
    public void practicarEnPareja(Jugador jugador) {

        if (jugador == null) {
            throw new IllegalArgumentException("El jugador no puede ser nulo");
        }

        if (jugador instanceof PracticarEnPareja) {
            ((PracticarEnPareja) jugador).practicaEnPareja();
        } else {
            System.out.println("Este jugador no puede practicar en pareja");
        }
    }


    public ArrayList<Jugador> filtrarPorSuperficie(Superficie superficie) {

        ArrayList<Jugador> resultado = new ArrayList<>();

        for (Jugador jugador : jugadores) {
            if (jugador.getSuperficie().equals(superficie)) {
                resultado.add(jugador);
                System.out.println(jugador.toString());
            }
        }

        return resultado;
    }


    public void generarResumenPorTipo() {

        int Singlistas = 0;
        int Doblistas = 0;
        int Juveniles = 0;

        for (Jugador jugador : jugadores) {

            if (jugador instanceof Singlista) {
                Singlistas++;
            } else if (jugador instanceof Doblista) {
                Doblistas++;
            } else if (jugador instanceof Juvenile) {
                Juveniles++;
            }
        }

        System.out.println("RESUMEN");
        System.out.println("Singlistas: " + Singlistas);
        System.out.println("Doblistas: " + Doblistas);
        System.out.println("Juveniles: " + Juveniles);
    }
    
    
    
}
