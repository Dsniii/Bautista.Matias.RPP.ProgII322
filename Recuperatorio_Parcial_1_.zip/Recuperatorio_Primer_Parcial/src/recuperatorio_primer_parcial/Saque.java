
package recuperatorio_primer_parcial;


public interface Saque {
    void sacar();
}
