
package recuperatorio_primer_parcial;


public class Recuperatorio_Primer_Parcial {

  
    public static void main(String[] args) {
        
         Vestuario vestuario = new Vestuario();
        
        try {
            
            vestuario.agregarJugador(new Singlista("Matias", 3, Superficie.CEMENTO, 205));
            vestuario.agregarJugador(new Doblista("Daniel", 1, Superficie.CESPED, 7));
            
            
            vestuario.agregarJugador(new Juvenile("Tomas", 20, Superficie.POLVO, true));

            
            vestuario.agregarJugador(new Singlista("Juelieta", 3, Superficie.CEMENTO, 210));

        } catch (JugadorDuplicadoException e) {
            System.out.println(e.getMessage());
        }

        System.out.println("MOSTRAR JUGADORES");
        vestuario.mostrarJugadores();

        System.out.println("ACCIONES");
        vestuario.sacar(new Doblista("Fake", 99, Superficie.CESPED, 8));  
        vestuario.practicarEnPareja(new Singlista("Fake2", 10, Superficie.POLVO, 190));  

        System.out.println("FILTRAR POR SUPEFICIE: POLVO ");
        vestuario.filtrarPorSuperficie(Superficie.POLVO);

        System.out.println("RESUMEN");
        vestuario.generarResumenPorTipo();
    }
        
        
        
}
    

    