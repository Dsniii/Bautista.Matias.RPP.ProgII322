
package recuperatorio_primer_parcial;


public enum Superficie {
    POLVO,
    CESPED,
    CEMENTO
    
    
}
