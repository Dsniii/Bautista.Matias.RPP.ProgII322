
package recuperatorio_primer_parcial;


public class Juvenile extends Jugador implements PracticarEnPareja {
    
    private boolean tutor;

    public Juvenile(String nombre, int ranking, Superficie superficie, boolean tutor) {
        super(nombre, ranking, superficie);
        this.tutor = tutor;
    }

    public boolean tieneTutor() {
        return tutor;
    }

    @Override
    public void practicaEnPareja() {
        System.out.println(getNombre() + " practica en pareja (juvenil).");
    }

    @Override
    public String toString() {
        return "Juvenil " + super.toString() +" tutor deportivo: " + tutor;
    }

    
    
    
}
