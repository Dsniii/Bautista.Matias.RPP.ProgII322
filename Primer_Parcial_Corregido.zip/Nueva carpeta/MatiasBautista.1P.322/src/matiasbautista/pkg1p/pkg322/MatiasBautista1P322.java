
package matiasbautista.pkg1p.pkg322;
import java.util.ArrayList;

public class MatiasBautista1P322 {

    
    public static void main(String[] args) throws PiezaDuplicada {
        
        
            Garaje garaje = new Garaje();

            
            System.out.println("Agregar piezas");
            garaje.agregarPieza(new Motores("Motor V8", "Parte trasera", CondicionClimatica.SECO, 950.0));
            garaje.agregarPieza(new Alas("Ala delantera", "Frontal", CondicionClimatica.LLUVIA, 8));
            
            
            

            
            
            garaje.mostrarPiezas();

           
            
            garaje.ajustarPiezas();

            garaje.buscarPiezasPorCondicion(CondicionClimatica.SECO);
           
            
        
        
    }
    
}
