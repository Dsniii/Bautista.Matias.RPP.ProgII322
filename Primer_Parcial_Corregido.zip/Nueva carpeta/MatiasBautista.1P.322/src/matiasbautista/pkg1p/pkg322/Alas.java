
package matiasbautista.pkg1p.pkg322;


public class Alas extends Pieza implements Ajustable{
    
    
    private double cargaAerodinamica;

    public Alas(String nombre, String ubicacion, CondicionClimatica condicion, int cargaAerodinamica) {
        super(nombre, ubicacion, condicion);
        this.cargaAerodinamica = cargaAerodinamica;
    }

    public double getCargaAerodinamica() {
        return cargaAerodinamica;
    }

    @Override
    public void ajustar() {
        System.out.println("Ajustando ala " + getNombre() + " para carga aerodinamica optima.");
    }

    @Override
    public String toString() {
        return super.toString() + " Carga aerodinamica: " + cargaAerodinamica + " de N";
    }
    
}
