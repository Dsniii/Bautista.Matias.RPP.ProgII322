
package matiasbautista.pkg1p.pkg322;
import java.util.ArrayList;

public class Garaje {
    
    private ArrayList<Pieza> piezas = new ArrayList<>();

    public void agregarPieza(Pieza pieza) throws PiezaDuplicada {
        
        if (verificarPieza(pieza)) {
                throw new PiezaDuplicada("La pieza '" + pieza.getNombre() + " ya existe en el garaje.");
                
            }
        
        piezas.add(pieza);
    }
    
    
    public boolean verificarPieza (Pieza piezaNueva){
        for (Pieza pieza: piezas){
            if (piezaNueva.existePieza(pieza)){
            return true;
            }      
        }
    return false;
    }
    
    
   
    public void mostrarPiezas() {
        for (Pieza pieza : piezas) {
            System.out.println(pieza);
        }
    }

    public void ajustarPiezas() {
        for (Pieza piezaAjustar : piezas) {
            if (piezaAjustar instanceof Ajustable) {
                ((Ajustable) piezaAjustar).ajustar();
            }
        }
    }

    public ArrayList<Pieza> buscarPiezasPorCondicion(CondicionClimatica condicion) {
    ArrayList<Pieza> resultado = new ArrayList<>();
    for (Pieza pieza : piezas) {
        if (pieza.getCondicion().equals(condicion)){ 
            resultado.add(pieza);
            System.out.println(pieza.toString());
        }
    }
    return resultado;
}

    
    
}
