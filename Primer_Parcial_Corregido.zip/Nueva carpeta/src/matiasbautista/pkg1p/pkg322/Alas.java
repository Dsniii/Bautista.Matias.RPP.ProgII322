                                                                   
package matiasbautista.pkg1p.pkg322;


public class Alas extends Pieza implements Ajustable{
    
    
    private double cargaAerodinamica;

    public Alas(String nombre, String ubicacion, CondicionClimatica condicion, int cargaAerodinamica) {
        super(nombre, ubicacion, condicion);
        
        
        if(cargaAerodinamica > 10 || cargaAerodinamica <= 0){
            
            throw new IllegalArgumentException ("La carga aerodinamica debe ser del 1 y 10");
              
        }
        this.cargaAerodinamica = cargaAerodinamica;
    }

    public double getCargaAerodinamica() {
        return cargaAerodinamica;
    }

    @Override
    public void ajustar() {
        System.out.println("Ajustando ala " + getNombre() + " para carga aerodinamica optima.");
    }

    @Override
    public String toString() {
        return super.toString() + " Carga aerodinamica: " + cargaAerodinamica + " de N";
    }
    
}
