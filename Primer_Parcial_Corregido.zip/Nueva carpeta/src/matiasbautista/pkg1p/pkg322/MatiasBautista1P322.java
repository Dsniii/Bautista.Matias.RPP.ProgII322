
package matiasbautista.pkg1p.pkg322;
import java.util.ArrayList;

public class MatiasBautista1P322 {

    
    public static void main(String[] args) throws PiezaDuplicada {
        
        try {
            
            Garaje garaje = new Garaje();
            Neumaticos n1 = new Neumaticos("Pirreli", "Parte trasera", CondicionClimatica.SECO, Compuesto.MEDIUM);

            
            System.out.println("Agregar piezas");
            garaje.agregarPieza(new Motores("Motor V8", "Parte trasera", CondicionClimatica.SECO, 950.0));
            //garaje.agregarPieza(new Motores("Motor V8", "Parte trasera", CondicionClimatica.SECO, 950.0));
            garaje.agregarPieza(new Alas("Ala delantera", "Frontal", CondicionClimatica.LLUVIA, 1));
            garaje.agregarPieza(new Neumaticos("Pirreli", "Parte trasera", CondicionClimatica.SECO, Compuesto.MEDIUM));
            
            
            
            garaje.mostrarPiezas();

            garaje.ajustarPiezas(n1);

            garaje.buscarPiezasPorCondicion(CondicionClimatica.SECO);
            

        }catch (PiezaDuplicada e){
                
            System.out.println(e.getMessage());
                
        }     
    }    
}
