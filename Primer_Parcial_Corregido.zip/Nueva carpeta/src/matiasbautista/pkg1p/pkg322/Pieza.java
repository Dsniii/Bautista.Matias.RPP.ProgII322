
package matiasbautista.pkg1p.pkg322;
import java.util.Objects;
import java.util.ArrayList;

public  abstract class Pieza {
    
    private String nombre;
    private String ubicacion;
    private CondicionClimatica condicion; 

    public Pieza(String nombre, String ubicacion, CondicionClimatica condicion) {
        
        if(nombre == null){
            throw new IllegalArgumentException ("El nombre no puede ser nulo.");
        }
        if(ubicacion == null){
            throw new IllegalArgumentException ("La ubicacion no puede ser nulo.");
        }
        if(condicion == null){
            throw new IllegalArgumentException ("La condicion no puede ser nulo.");
        }
        
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.condicion = condicion;
        
    }

    public String getNombre() {
        return nombre;
    }

    public String getUbicacion() {
        return ubicacion;
    }

    public CondicionClimatica getCondicion() {
        return condicion;
    }

    

    @Override
    public String toString() {
        return "Pieza " + nombre + " Ubicacion " + ubicacion + " Condicion " + condicion;
    }
    
  
    @Override
    public boolean equals(Object objeto) {
        if (this == objeto){
            return true;
        }
        
        if (objeto == null || getClass() != objeto.getClass()){
            return false;
        }
        
        Pieza otra = (Pieza) objeto;
        return nombre.equals(otra.nombre) && ubicacion.equals(otra.ubicacion);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nombre, ubicacion);
    }
    
}
